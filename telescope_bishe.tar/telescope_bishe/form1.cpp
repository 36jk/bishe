#include "form1.h"
#include "ui_Telescope.h"

Form::Form(QWidget *parent) : QWidget(parent), ui(new Ui::Form) {
    ui->setupUi(this);

    connect(ui->addball_button, &QPushButton::clicked, this, &Form::addball);
    connect(ui->deleteball_button, &QPushButton::clicked, this, &Form::deleteball);
    connect(ui->Star_database, &QListWidget::itemClicked, this, &Form::Star);
}

Form::~Form() {
    delete ui;
}

void Form::addball() {
    QString ballname = ui->addlineEdit_ballname->text();
    QString ball_RA = ui->addLineEdit_RA->text();
    QString ball_DEC = ui->addLineEdit_DEC->text();

    if (ballname.isEmpty() || ball_DEC.isEmpty() || ball_RA.isEmpty()) {
        QMessageBox::warning(this, "输入不能为空", "星球名称、RA、DEC不可为空");
        return;
    }

    // 创建一个 QListWidgetItem，并将星球名称显示在列表中
    QListWidgetItem *item = new QListWidgetItem(ballname, ui->Star_database);

    // 将完整信息（名称:RA,DEC）存储在 item 的 Qt::UserRole 数据中
    QString ballinfo = ballname + ":" + ball_RA + "," + ball_DEC;
    item->setData(Qt::UserRole, ballinfo);

    // 清空输入框
    ui->addlineEdit_ballname->clear();
    ui->addLineEdit_DEC->clear();
    ui->addLineEdit_RA->clear();
}

void Form::deleteball() {
    QListWidgetItem *selectedItem = ui->Star_database->currentItem();
    if (selectedItem) {
        delete selectedItem;
    }
}

void Form::Star(QListWidgetItem *item) {
    if (!item) {
        QMessageBox::warning(this, "错误", "未选择任何星球");
        return;
    }

    // 从 item 的 Qt::UserRole 数据中提取完整信息
    QString ballinfo = item->data(Qt::UserRole).toString();
    QStringList parts = ballinfo.split(":");

    if (parts.size() == 2) {
        QStringList coords = parts[1].split(",");
        if (coords.size() == 2) {
            ui->SLineEdit_RA->setText(coords[0].trimmed());
            ui->SLineEdit_DEC->setText(coords[1].trimmed());
        }
    }
}
