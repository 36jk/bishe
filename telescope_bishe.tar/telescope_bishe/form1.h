#ifndef FORM1_H
#define FORM1_H

#include <QWidget>
#include <QProcess>
#include <QListWidgetItem>
#include <QMessageBox>

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

private slots:
    void addball();
    void deleteball();
    void Star();

private:
    Ui::Form *ui;
    QProcess *process;
};

#endif // FORM1_H
